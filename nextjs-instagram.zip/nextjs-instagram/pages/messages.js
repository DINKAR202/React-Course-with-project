import React from "react";
import Layout from "../components/layout";

export default function Messages() {
  return (
    <Layout>
      <div>Messages</div>
    </Layout>
  );
}
