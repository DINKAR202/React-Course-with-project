import React from "react";
import Layout from "../components/layout";

export default function Explore() {
  return (
    <Layout>
      <div>Explore</div>
    </Layout>
  );
}
